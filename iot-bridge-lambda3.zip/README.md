# iot-bridge-lambda

secrets.json location - https://drive.google.com/file/d/1OAg-fVvWNEe0AZJ-StsMD2Irb8Uvp-Kb/view?usp=share_link
lambda function - https://us-west-2.console.aws.amazon.com/lambda/home?region=us-west-2#/functions/IoTBridge?tab=code